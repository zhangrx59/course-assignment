import numpy as np
import matplotlib.pyplot as plt
import random
import math
# 辅助函数定义
def encode(x):
    int_part = int(np.floor(x))
    dec_part = x - int_part
    dec_part_scaled = int(np.round(dec_part * 10000))  # 小数点后四位
    return format(int_part, '01b') + format(dec_part_scaled, '014b')  # 增加到14位二进制数
def decode(bin_str):
    int_part = int(bin_str[0:1], 2)
    dec_part_scaled = int(bin_str[1:], 2) / 10000 # 将14位二进制数转换回小数
    return int_part + dec_part_scaled
def mutation(individual, mutation_point):
    mutant = list(individual)
    mutant[mutation_point] = '0' if mutant[mutation_point] == '1' else '1'
    return ''.join(mutant)
def crossover(parent1, parent2, crossover_point):
    return parent1[:crossover_point] + parent2[crossover_point:], parent2[:crossover_point] + parent1[crossover_point:]

# 参数集
param_sets = np.array([
    [10, 0.6, 0.2, 10, 15],
    [20, 0.6, 0.2, 10, 15],
    [20, 0.6, 0.2, 10, 15],
    [20, 0.2, 0.2, 10, 15],
    [20, 0.6, 0.2, 20, 30],
    [20, 0.6, 0.2, 5, 7]
])

# 运行进化算法
all_curves = np.zeros((param_sets.shape[0], int(np.max(param_sets[:, 0]))))
for i in range(param_sets.shape[0]):
    Gen, pc, pm, P0, P = param_sets[i]
    best_curve = np.zeros(int(Gen))
    # 初始化种群，确保 x 在 [1, 4] 范围内
    pop = 1 + 3 * np.random.rand(int(P0))  # 生成 [1, 4] 范围内的随机数
    pop_bin = list(map(encode, pop))

    for gen in range(int(Gen)):
        pop = np.array(list(map(decode, pop_bin)))
        # 计算适应度函数
        fitness = (pop - 2)**2
        best_fitness = np.min(fitness)
        best_curve[gen] = best_fitness
        for _ in range(int(round(pc * P0))):
            parents = random.sample(pop_bin, 2)
            min_length = min(len(parents[0]), len(parents[1]))
            crossover_point = random.randint(1, min_length - 1)
            child1, child2 = crossover(parents[0], parents[1], crossover_point)
            pop_bin.extend([child1, child2])
        for _ in range(int(round(pm * len(pop_bin)))):
            mutant_idx = random.randint(0, len(pop_bin) - 1)
            mutation_point = random.randint(0, len(pop_bin[mutant_idx]) - 1)
            pop_bin[mutant_idx] = mutation(pop_bin[mutant_idx], mutation_point)
        if len(pop_bin) > P:
            pop_bin = random.sample(pop_bin, int(P))
        all_curves[i, :int(Gen)] = best_curve
# 绘制所有曲线
plt.figure()
for i in range(param_sets.shape[0]):
    plt.plot(all_curves[i], label=' '.join(map(str, param_sets[i])), linewidth=2)
plt.title('Best fitness over generations for different parameter sets')
plt.xlabel('Generation')
plt.ylabel('Best fitness')
plt.legend()
plt.grid(True)
plt.show()