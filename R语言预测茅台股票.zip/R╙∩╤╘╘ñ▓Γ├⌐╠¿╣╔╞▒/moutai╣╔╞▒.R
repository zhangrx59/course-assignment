rm(list=ls())# 清空工作环境
# 读取数据
maotai <- read.csv("D:/600519.csv")

# 将收盘价列转换为数值型
maotai$收盘 <- as.numeric(gsub(",", "", maotai$收盘))

# 计算收盘价的平均数、中位数和标准差
mean_close <- mean(maotai$收盘)
median_close <- median(maotai$收盘)
sd_close <- sd(maotai$收盘)

# 打印结果
print(paste("平均数:", mean_close))
print(paste("中位数:", median_close))
print(paste("标准差:", sd_close))
# 计算偏度
skewness <- mean(((maotai$收盘 - mean_close) / sd_close) ^ 3)

# 计算峰度
kurtosis <- mean(((maotai$收盘 - mean_close) / sd_close) ^ 4)

# 打印偏度和峰度
print(paste("偏度:", skewness))
print(paste("峰度:", kurtosis))

# 绘制比亚迪收盘价时序图
plot(maotai$收盘, type = "o", col = "green", pch = 13, main = "茅台收盘价时序图")
# 进行一阶差分
diff_maotai <- diff(maotai$收盘)

# 绘制差分后的时序图
plot(diff_maotai, col = 5, main = "茅台收盘价数据序列一阶差分后的时序图")
install.packages("tseries")

# 差分后序列平稳性检验
library(tseries)
adf.test(diff_maotai)



# 差分后序列纯随机性检验
for(k in 1:2)
  print(Box.test(diff_maotai, lag = 6 * k, type = "Ljung-Box"))

# 绘制差分后序列的自相关图和偏自相关图
par(mfrow = c(1, 2))
acf(diff_maotai)
pacf(diff_maotai)
# 模型识别
install.packages("forecast")
library(forecast)
fit1 <- Arima(maotai$收盘, order = c(1, 1, 1), include.drift = TRUE)
fit1

# 模型预测
fore1 <- forecast::forecast(fit1, h = 5)
fore1

par(mfrow = c(1, 1))
plot(fore1, lty = 2)
lines(fore1$fitted, col = 4)

# 显著性检验
tsdiag(fit1)

# 残差进行独立性检验
install.packages("ggplot2")
library(ggplot2)
autoplot(fit1$residuals)

plotForecastErrors <- function(forecasterrors) {
  mysd <- sd(forecasterrors)
  hist(forecasterrors, col = "red", freq = FALSE)
  mynorm <- rnorm(10000, mean = 0, sd = mysd)
  myhist <- hist(mynorm, plot = FALSE)
  points(myhist$mids, myhist$density, type = "l", col = "blue", lwd = 2)
}
plotForecastErrors(fit1$residuals)
acf(fit1$residuals)
Box.test(fit1$residuals, lag = 1, type = "Ljung-Box")

